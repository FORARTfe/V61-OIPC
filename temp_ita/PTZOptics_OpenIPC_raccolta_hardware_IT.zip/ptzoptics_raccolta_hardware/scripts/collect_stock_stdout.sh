#!/bin/sh
# Eseguire esclusivamente nel firmware originale, tramite shell autorizzata.
# Scrive soltanto su stdout/stderr: non crea file, non apre periferiche raw,
# non cambia configurazione, non carica/scarica moduli.
# Il sistema originale puo' comunque aggiornare log e metadati autonomamente.
# I risultati possono contenere indirizzi, identificativi o segreti: revisionarli.

heading() { printf '\n===== %s =====\n' "$*"; }
show() {
    heading "$1"
    if [ -r "$1" ]; then cat "$1"; else printf 'NON DISPONIBILE\n'; fi
}
run() {
    heading "$*"
    if command -v "$1" >/dev/null 2>&1; then
        "$@" 2>&1 || printf '[comando terminato con errore]\n'
    else
        printf 'COMANDO NON DISPONIBILE\n'
    fi
}
run date -u
run id
run uname -a
for f in /proc/version /proc/cpuinfo /proc/cmdline /proc/meminfo \
         /proc/iomem /proc/mtd /proc/partitions /proc/modules \
         /proc/mounts /proc/interrupts /proc/devices; do
    show "$f"
done
run dmesg
run ps
run df -k
run netstat -an
run ls -l /dev
run ls -l /home
run ls -l /home/ko
run ls -l /home/ko/extdrv
run ls -l /proc/umap
run ls -l /proc/msp
run ls -l /sys/bus/i2c/devices
run ls -l /sys/bus/spi/devices
run ls -l /sys/class/tty
for d in /sys/class/mtd/mtd[0-9]*; do
    [ -d "$d" ] || continue
    n=${d##*/}; number=${n#mtd}
    case "$number" in ''|*[!0-9]*) continue ;; esac
    for attr in name type size erasesize writesize oobsize offset; do
        show "$d/$attr"
    done
done
for f in /etc/inittab /etc/init.d/rcS /etc/fw_env.config \
         /home/vhd_start.sh /home/ko/load3516a; do
    show "$f"
done
heading FINE_RACCOLTA
printf 'Nessun backup flash e nessuna lettura della UART PTZ sono stati eseguiti.\n'
