#!/usr/bin/env python3
"""Inventario MTD e doppia lettura NOR via SSH, con file salvati SOLO sul PC.

Nessun firmware viene scritto. Nessun dispositivo viene aperto in scrittura
sulla telecamera. Questo NON garantisce un backup atomico del sistema in uso,
ne' un dump dell'intero chip, ne' la possibilita' di ripristino.
Richiede Python 3.9+ e OpenSSH sul PC; sh, cat e dd sul sistema originale.
Senza --read-nor effettua soltanto l'inventario, senza leggere il contenuto MTD.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
from typing import Any

MTD_LINE = re.compile(r'^mtd(\d+):\s+([0-9a-fA-F]+)\s+([0-9a-fA-F]+)\s+"([^"\r\n]*)"$')
HOST = re.compile(r'(?:[A-Za-z0-9_.-]+@)?[A-Za-z0-9][A-Za-z0-9.-]*')
PART = re.compile(r'mtd\d+')


def parse_mtd(text: str) -> list[dict[str, Any]]:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if not lines or not re.fullmatch(r'dev:\s+size\s+erasesize\s+name', lines[0]):
        raise ValueError('Intestazione /proc/mtd inattesa; possibile banner su stdout.')
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for line in lines[1:]:
        m = MTD_LINE.fullmatch(line)
        if not m:
            raise ValueError(f'Riga /proc/mtd non riconosciuta: {line!r}')
        part = 'mtd' + m[1]
        size, erase = int(m[2], 16), int(m[3], 16)
        if part in seen or not 0 < size <= 1024**3 or not 0 < erase <= size:
            raise ValueError(f'Geometria duplicata/non plausibile per {part}')
        seen.add(part)
        result.append(dict(part=part, name=m[4], size=size, erasesize=erase))
    if not result:
        raise ValueError('Nessun dispositivo MTD trovato.')
    return result


def metadata_script(part: str) -> str:
    if not PART.fullmatch(part):
        raise ValueError('Nome MTD non valido')
    return f'''set -eu
b=/sys/class/mtd/{part}
for k in type size erasesize writesize oobsize; do
    test -r "$b/$k" || {{ echo "Attributo assente: $k" >&2; exit 2; }}
    v=$(cat "$b/$k")
    printf '%s=%s\\n' "$k" "$v"
done
if test -c /dev/{part}ro && test -r /dev/{part}ro; then
    printf 'source=/dev/{part}ro\\n'
elif test -c /dev/{part} && test -r /dev/{part}; then
    printf 'source=/dev/{part}\\n'
else
    echo 'Nodo carattere MTD non leggibile' >&2; exit 2
fi
'''


def parse_metadata(text: str, item: dict[str, Any]) -> dict[str, Any]:
    data: dict[str, str] = {}
    for line in text.splitlines():
        if '=' not in line:
            raise ValueError('Metadati inattesi; controllare banner e log SSH.')
        key, value = line.split('=', 1)
        if key in data:
            raise ValueError('Attributo MTD duplicato')
        data[key] = value
    required = {'type', 'size', 'erasesize', 'writesize', 'oobsize', 'source'}
    if set(data) != required:
        raise ValueError('Attributi MTD incompleti o inattesi')
    for key in ('size', 'erasesize', 'writesize', 'oobsize'):
        if not data[key].isdigit():
            raise ValueError(f'Attributo {key} non numerico')
    if int(data['size']) != item['size'] or int(data['erasesize']) != item['erasesize']:
        raise ValueError('Geometria sysfs diversa da /proc/mtd')
    part = item['part']
    if data['source'] not in (f'/dev/{part}', f'/dev/{part}ro'):
        raise ValueError('Sorgente MTD non ammessa')
    return {**item, 'type': data['type'], 'writesize': int(data['writesize']),
            'oobsize': int(data['oobsize']), 'source': data['source']}


def require_nor(items: list[dict[str, Any]]) -> None:
    for item in items:
        if item['type'] != 'nor' or item['oobsize'] != 0 or item['writesize'] != 1:
            raise ValueError(f"{item['part']}: richiede NOR classica, writesize=1, oobsize=0; "
                             'NAND, UBI, tipi ignoti e NOR non standard non sono gestiti.')


def dump_script(item: dict[str, Any]) -> str:
    require_nor([item])
    part = item['part']
    if not PART.fullmatch(part) or item['source'] not in (f'/dev/{part}', f'/dev/{part}ro'):
        raise ValueError('Nome sorgente non valido')
    size = int(item['size'])
    return f'''set -eu
b=/sys/class/mtd/{part}
test "$(cat "$b/type")" = nor
test "$(cat "$b/size")" = {size}
test "$(cat "$b/oobsize")" = 0
test "$(cat "$b/writesize")" = 1
test -c {item['source']}
exec dd if={item['source']} bs=65536
'''


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def check_dump(path: Path, expected: int) -> str:
    actual = path.stat().st_size
    if actual != expected:
        raise ValueError(f'{path.name}: {actual} byte, attesi {expected}; dump non valido.')
    return sha256_file(path)


def run_text(ssh: list[str], script: str, log: Path) -> str:
    with log.open('xb') as error:
        proc = subprocess.run(ssh, input=script.encode('ascii'), stdout=subprocess.PIPE,
                              stderr=error, timeout=60, check=True)
    return proc.stdout.decode('utf-8', errors='strict')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--host', required=True, help='Utente@IPv4 oppure alias SSH noto; no URL/IPv6')
    parser.add_argument('--port', type=int, default=22)
    parser.add_argument('--out', type=Path, required=True, help='Nuova directory LOCALE sul PC')
    parser.add_argument('--read-nor', action='store_true', help='Legge due volte tutte le MTD NOR confermate')
    args = parser.parse_args()
    if not HOST.fullmatch(args.host) or not 1 <= args.port <= 65535:
        parser.error('Host/porta non ammessi')
    if not shutil.which('ssh'):
        parser.error('OpenSSH client non trovato sul PC')
    os.umask(0o077)
    out = args.out.expanduser().absolute()
    try:
        out.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        parser.error('La directory esiste gia: scegliere un nuovo nome; nessun file sovrascritto.')
    ssh = ['ssh', '-T', '-o', 'ConnectTimeout=10', '-p', str(args.port), args.host, 'sh', '-s']
    try:
        proc_mtd = run_text(ssh, 'cat /proc/mtd\n', out / 'ssh_inventory.stderr.txt')
        (out / 'proc_mtd.txt').write_text(proc_mtd, encoding='utf-8')
        items = parse_mtd(proc_mtd)
        full: list[dict[str, Any]] = []
        for item in items:
            part = item['part']
            text = run_text(ssh, metadata_script(part), out / f'{part}_metadata.stderr.txt')
            (out / f'{part}_metadata.txt').write_text(text, encoding='utf-8')
            full.append(parse_metadata(text, item))
        report: dict[str, Any] = {
            'created_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
            'host': args.host, 'port': args.port, 'partitions': full,
            'mode': 'two_live_nor_reads' if args.read_nor else 'inventory_only',
            'warning': 'Non e un backup atomico ne una prova di ripristino o copertura fisica totale.',
        }
        (out / 'inventory.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        for item in full:
            print(f"{item['part']}: {item['name']} | {item['type']} | {item['size']} byte | {item['source']}")
        if not args.read_nor:
            print('Solo inventario: nessun contenuto flash letto.')
            return 0
        require_nor(full)  # Verifica TUTTE le MTD prima della prima lettura raw.
        required = 2 * sum(item['size'] for item in full) + 16 * 1024**2
        if shutil.disk_usage(out).free < required:
            raise ValueError('Spazio locale insufficiente per due letture e log.')
        reads: dict[str, dict[str, str]] = {'A': {}, 'B': {}}
        manifest: list[str] = []
        for pass_name in ('A', 'B'):
            folder = out / f'lettura_{pass_name}'
            folder.mkdir()
            for item in full:
                part = item['part']
                partial = folder / f'{part}.bin.partial'
                with partial.open('xb') as destination, (folder / f'{part}.stderr.txt').open('xb') as error:
                    subprocess.run(ssh, input=dump_script(item).encode('ascii'), stdout=destination,
                                   stderr=error, timeout=300, check=True)
                digest = check_dump(partial, item['size'])
                final = folder / f'{part}.bin'
                partial.rename(final)
                reads[pass_name][part] = digest
                manifest.append(f'{digest}  {final.relative_to(out).as_posix()}')
                print(f'Lettura {pass_name}: {part}, lunghezza verificata, SHA256={digest}')
        differences = [item['part'] for item in full
                       if reads['A'][item['part']] != reads['B'][item['part']]]
        report.update(sha256=reads, different_between_reads=differences)
        (out / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
        (out / 'SHA256SUMS.txt').write_text('\n'.join(manifest) + '\n', encoding='ascii')
        if differences:
            print('ATTENZIONE: letture diverse per ' + ', '.join(differences) +
                  '. Conservare entrambe; possibili scritture stock o problema di lettura.', file=sys.stderr)
            return 3
        print('Letture uguali e dimensioni verificate. Il ripristino NON e stato provato.')
        return 0
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        (out / 'ERROR.txt').write_text(str(error) + '\n', encoding='utf-8')
        print(f'INTERROTTO: {error}. Conservare log e file .partial senza considerarli backup validi.', file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print('Interrotto dall utente. Nessuna scrittura flash; file .partial incompleti.', file=sys.stderr)
        return 130


if __name__ == '__main__':
    sys.exit(main())
