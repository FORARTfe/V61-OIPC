# Inventario della camera

ID caso:
Data/ora/fuso:
Operatore:
Modello esatto sull'etichetta:
Revisione hardware indicata:
Seriale e MAC: conservati nel dossier riservato / assenti
Prefisso MAC per scelta utility ufficiale:
Firmware principale:
Firmware MCU/ARM, se mostrato:
Nome dispositivo nella UI:
NDI: attivo / non attivo / non noto
Versione ricevitore NDI:
Alimentazione utilizzata:
Posizione originale selettore video:
Stream 1: codec, risoluzione, fps, bitrate, porta/percorso:
Stream 2: codec, risoluzione, fps, bitrate, porta/percorso:
Autenticazione RTSP: attiva / non attiva / non nota
Audio: ingresso, codifica e instradamento osservato:
Protocollo PTZ di utilizzo:
Controller e versione:
VISCA: indirizzo e porte effettive:
RS-232/RS-485 esterne: configurazione effettiva:
Preset in uso, senza modificarli:
Limiti e orientamento:
Shell autorizzata: SSH / console / Telnet / assente
Accesso root: confermato / assente / non noto
File schermate e foto etichette:
Eventuali discrepanze rispetto all'IMG o al manuale:
