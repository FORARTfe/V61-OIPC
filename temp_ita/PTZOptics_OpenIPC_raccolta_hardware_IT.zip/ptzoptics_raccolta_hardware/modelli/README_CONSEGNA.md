# Riepilogo della raccolta

Compilare con dati osservati. Scrivere "non eseguito" o "non disponibile" dove necessario.

## Identificazione

Caso / pseudonimo camera:
Data e fuso orario:
Modello da etichetta:
Revisione PCB:
Versione firmware in esecuzione:
Corrispondenza con IMG gia fornito: verificata / non verificata / diversa

## Materiale incluso

Inventario e schermate:
Backup ufficiale: esito, dimensioni, hash; contenuti riservati conservati localmente:
Foto:
UART e U-Boot:
Diagnostica Linux:
Inventario MTD:
Letture flash: non eseguite / due uguali / due diverse / errori
Tracce PTZ:
Misure video e audio:
Dati sul recupero:

## Stato finale della camera

Avvio originale ancora funzionante:
PTZ originale ancora funzionante:
Uscite originali ancora funzionanti:
Parametri modificati durante le prove e ripristinati:
Preset usati o creati:
Anomalie e file di log associati:

## Requisiti indispensabili

Modalita HDMI e SDI richieste:
Codec, risoluzioni e frame rate RTSP richiesti:
Audio e sincronismo:
NDI necessario oppure facoltativo:
Controllori e protocolli PTZ usati:
Altre funzioni da conservare:

## Limiti

Operazioni non eseguite e motivo:
Strumenti disponibili:
Disponibilita della camera per ulteriori test:
Recupero: non definito / documentato / provato in precedenza, con evidenza

## Riservatezza

File esclusi per presenza di credenziali, chiavi o identificativi:
Anonimizzazioni eseguite sulle copie:
Originali conservati separatamente: si / no
