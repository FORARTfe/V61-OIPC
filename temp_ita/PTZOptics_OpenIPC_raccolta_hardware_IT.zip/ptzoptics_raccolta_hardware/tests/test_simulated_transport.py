"""Test del programma completo con un eseguibile SSH simulato; nessuna rete."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'scripts' / 'backup_nor_via_ssh.py'
FAKE_SSH = '''#!/usr/bin/env python3
import os, sys
s = sys.stdin.read()
if s == 'cat /proc/mtd\\n':
    print('dev:    size   erasesize  name\\nmtd0: 00000004 00000004 "test"')
elif 'for k in type size erasesize' in s:
    t = os.environ.get('TEST_MTD_TYPE', 'nor')
    print('type=' + t + '\\nsize=4\\nerasesize=4\\nwritesize=1\\noobsize=0\\nsource=/dev/mtd0ro')
elif 'exec dd if=/dev/mtd0ro bs=65536' in s:
    if os.environ.get('TEST_MTD_TYPE') == 'nand':
        raise SystemExit('ERRORE: dump NAND non atteso')
    sys.stdout.buffer.write(b'abcd')
else:
    raise SystemExit('Comando simulato non riconosciuto')
'''

class TestTransport(unittest.TestCase):
    def execute(self, *, read=False, nand=False):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        base = Path(tmp.name)
        fake = base / 'ssh'; fake.write_text(FAKE_SSH); fake.chmod(0o700)
        env = os.environ.copy()
        env['PATH'] = str(base) + os.pathsep + env['PATH']
        if nand:
            env['TEST_MTD_TYPE'] = 'nand'
        out = base / 'output'
        command = [sys.executable, str(SCRIPT), '--host', 'test@camera.invalid', '--out', str(out)]
        if read:
            command.append('--read-nor')
        p = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=20)
        return p, out

    def test_inventory_does_not_dump(self):
        p, out = self.execute()
        self.assertEqual(p.returncode, 0, p.stderr.decode())
        self.assertEqual(json.loads((out / 'inventory.json').read_text())['mode'], 'inventory_only')
        self.assertEqual(list(out.rglob('*.bin')), [])

    def test_two_binary_reads(self):
        p, out = self.execute(read=True)
        self.assertEqual(p.returncode, 0, p.stderr.decode())
        self.assertEqual((out / 'lettura_A/mtd0.bin').read_bytes(), b'abcd')
        self.assertEqual((out / 'lettura_B/mtd0.bin').read_bytes(), b'abcd')
        self.assertEqual(json.loads((out / 'comparison.json').read_text())['different_between_reads'], [])

    def test_nand_stops_before_dump(self):
        p, out = self.execute(read=True, nand=True)
        self.assertEqual(p.returncode, 1)
        self.assertTrue((out / 'ERROR.txt').exists())
        self.assertEqual(list(out.rglob('*.bin')), [])

if __name__ == '__main__':
    unittest.main()
