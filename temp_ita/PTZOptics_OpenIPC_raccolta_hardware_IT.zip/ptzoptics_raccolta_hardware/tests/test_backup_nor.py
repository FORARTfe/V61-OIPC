import importlib.util
from pathlib import Path
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location('backup', Path(__file__).resolve().parents[1] / 'scripts' / 'backup_nor_via_ssh.py')
backup = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(backup)

PROC = 'dev:    size   erasesize  name\nmtd0: 00080000 00010000 "boot"\n'
META = 'type=nor\nsize=524288\nerasesize=65536\nwritesize=1\noobsize=0\nsource=/dev/mtd0ro\n'

class TestGuards(unittest.TestCase):
    def item(self):
        return backup.parse_metadata(META, backup.parse_mtd(PROC)[0])

    def test_valid_geometry(self):
        self.assertEqual(self.item()['size'], 524288)

    def test_reject_banner(self):
        with self.assertRaises(ValueError):
            backup.parse_mtd('Welcome\n' + PROC)

    def test_reject_duplicate_partition(self):
        with self.assertRaises(ValueError):
            backup.parse_mtd(PROC + PROC.splitlines()[1] + '\n')

    def test_reject_missing_metadata(self):
        with self.assertRaises(ValueError):
            backup.parse_metadata(META.replace('type=nor\n', ''), backup.parse_mtd(PROC)[0])

    def test_reject_wrong_geometry(self):
        with self.assertRaises(ValueError):
            backup.parse_metadata(META.replace('524288', '1048576'), backup.parse_mtd(PROC)[0])

    def test_reject_nand(self):
        item = self.item(); item['type'] = 'nand'
        with self.assertRaises(ValueError):
            backup.require_nor([item])

    def test_reject_oob(self):
        item = self.item(); item['oobsize'] = 64
        with self.assertRaises(ValueError):
            backup.require_nor([item])

    def test_reject_unknown_source(self):
        with self.assertRaises(ValueError):
            backup.parse_metadata(META.replace('/dev/mtd0ro', '/dev/mtdblock0'), backup.parse_mtd(PROC)[0])

    def test_reject_script_injection(self):
        with self.assertRaises(ValueError):
            backup.metadata_script('mtd0; reboot')

    def test_dump_has_input_only(self):
        script = backup.dump_script(self.item())
        self.assertIn('exec dd if=/dev/mtd0ro bs=65536', script)
        self.assertNotIn('of=', script)
        self.assertNotIn('mtdblock', script)

    def test_sha256_and_length(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'test.bin'; p.write_bytes(b'abc')
            self.assertEqual(backup.check_dump(p, 3), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad')
            with self.assertRaises(ValueError):
                backup.check_dump(p, 4)

if __name__ == '__main__':
    unittest.main()
